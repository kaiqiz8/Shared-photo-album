IShape: interface of shapes

AbstractShape: abstract class that extends IShape interface

Rectangle / Oval : concrete class that implements IShape interface

ShapePosition is a wrapper class that composed of shape and its position on photo album

SnapShots class is responsible for taking snapshots.

Canvas is the implementation of photo album. It has the following major functionality: create shape, 
move shape, change shape width/height, place shape on photo album, take snapshots, show a list of all snapshots taken,
show history of all commands used, and reset the photo album. CreateShape create new Rectangle/Oval class depending on the input.
MoveShape links shapePosition objects and change shape's position through shapePosition class. 
changeShapeColor/ changeShapeX/ changeShapeY method is performed through linking shapePosition 
and IShape class. PlaceShape methods creates new shapePosition object and store it in a list. 
TakeSnapshot methods create new SnapShots objects and store it in a list;